function plotStrain(e,type)
imagesc(e)
colormap jet
axis equal
axis off
colormap jet
colorbar
title(['Strain: ',type])
end