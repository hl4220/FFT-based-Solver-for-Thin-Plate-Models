%% FFT homogenisation for woven composite RVE: CPT
% Variables
% T: Green's Function
% cons: Constitutive information for membrane and bending  
% e: strain
% r: curvature
% s: stress
% m: moment
%% 
clc 
clear
% Load the material
load('Data/C0075/Kmat3_160.mat','Kmat3_Cells')
% Applied average strain and curvature 
% [e11,e22,e12,r11,r22,r12]
eps_bar = [1,0,0,0,0,0];
% Dimension of the plate
Lx = 4; Ly = 4;
% Number of Elements
m = 160; n = 160;
% Change the constitutive matrix
cons = zeros(m*n,36); 
Kmat3_Cells = reshape(reshape(Kmat3_Cells,[m,n])',[],1);
for i=1:size(Kmat3_Cells,1)
    Kmat3 = Kmat3_Cells{i};
    cons(i,:) = [reshape(Kmat3(1:3,1:3),[1,9]), ...
                 reshape(Kmat3(1:3,4:6),[1,9]), ...
                 reshape(Kmat3(4:6,4:6),[1,9]), ...
                 reshape(Kmat3(4:6,1:3),[1,9])];
end
%% Determine the reference properties
Eig_m = zeros(m*n,3); Eig_b = zeros(m*n,3);
for i = 1:m*n 
    Eig_m(i,:) = (eig(reshape(cons(i,1:9),[3,3])))';
    Eig_b(i,:) = (eig(reshape(cons(i,19:27),[3,3])))';
    CT = Kmat3_Cells{i};
end 
Eig_m_min = min(min(Eig_m)); Eig_m_max = max(max(Eig_m));
Eig_b_min = min(min(Eig_b)); Eig_b_max = max(max(Eig_b));
lambda0_m = (Eig_m_min+Eig_m_max)*0; lambda0_b = (Eig_b_min+Eig_b_max)*0;
mu0_m = (Eig_m_min+Eig_m_max)*0.5; mu0_b = (Eig_b_min+Eig_b_max)*0.5;
%% Frequence sequence
em = pi*[0:m/2-1,-m/2:-1]/m; en = pi*[0:n/2-1,-n/2:-1]/n;
[ex,ey] = meshgrid(em,en);
e1t = m/Lx.*sin(ey).*cos(ex); e2t = n/Ly.*cos(ey).*sin(ex);
%% Green's Function
[T11,T12,T13,T21,T22,T23,T31,T32,T33] = ...
    GreenFunction_Membrane(mu0_m,lambda0_m,e1t,e2t,m,n);
[T11w,T12w,T13w,T21w,T22w,T23w,T31w,T32w,T33w] = ...
    GreenFunction_Bending_CPT(mu0_b,lambda0_b,e1t,e2t,m,n);
%%  initialize the strain and stress 
e11 = eps_bar(1)*ones(m,n); e22 = eps_bar(2)*ones(m,n); 
e12 = eps_bar(3)*ones(m,n); 
r11 = eps_bar(4)*ones(m,n); r22 = eps_bar(5)*ones(m,n); 
r12 = eps_bar(6)*ones(m,n);
%% Computing 
% Change to vector
e11 = reshape(e11,[],1); e22 = reshape(e22,[],1); 
e12 = reshape(e12,[],1); 
r11 = reshape(r11,[],1); r22 = reshape(r22,[],1); 
r12 = reshape(r12,[],1); 
% Calculate the stress
eT = [e11,e22,e12];
rT = [r11,r22,r12];
s11 = sum(cons(:,1:3).*eT,2) + sum(cons(:,10:12).*rT,2);
s22 = sum(cons(:,4:6).*eT,2) + sum(cons(:,13:15).*rT,2);
s12 = sum(cons(:,7:9).*eT,2) + sum(cons(:,16:18).*rT,2);
m11 = sum(cons(:,28:30).*eT,2) + sum(cons(:,19:21).*rT,2); 
m22 = sum(cons(:,31:33).*eT,2) + sum(cons(:,22:24).*rT,2);
m12 = sum(cons(:,34:36).*eT,2) + sum(cons(:,25:27).*rT,2);
% Change back to the matrix
e11 = reshape(e11,[m,n]); s11 = reshape(s11,[m,n]);
e22 = reshape(e22,[m,n]); s22 = reshape(s22,[m,n]);
e12 = reshape(e12,[m,n]); s12 = reshape(s12,[m,n]);
r11 = reshape(r11,[m,n]); m11 = reshape(m11,[m,n]);
r22 = reshape(r22,[m,n]); m22 = reshape(m22,[m,n]);
r12 = reshape(r12,[m,n]); m12 = reshape(m12,[m,n]);
% FFT on the strain
e11fft = (fftn(e11)); e22fft = (fftn(e22));
e12fft = (fftn(e12));
r11fft = (fftn(r11)); r22fft = (fftn(r22));
r12fft = (fftn(r12));
% Initial convergence value
ec = inf;
iter = 0;
%% Go to the iteration for FFT main program
disp('Start the iteration')
while ec > 1e-4
    iter = iter+1;
    % FFT on the stress
    s11fft = (fftn(s11)); s22fft = (fftn(s22)); 
    s12fft = (fftn(s12)); 
    m11fft = (fftn(m11)); m22fft = (fftn(m22)); 
    m12fft = (fftn(m12)); 
    % Convergence test
    ec = Conve_Crit_CPT(s11fft,s22fft,s12fft,m11fft,m22fft,m12fft,e1t,e2t);
    % Update the strain
    e11fft = e11fft - (T11.*s11fft + T12.*s22fft + T13.*s12fft);
    e22fft = e22fft - (T21.*s11fft + T22.*s22fft + T23.*s12fft);
    e12fft = e12fft - (T31.*s11fft + T32.*s22fft + T33.*s12fft);
    r11fft = r11fft - (T11w.*m11fft + T12w.*m22fft + T13w.*m12fft);
    r22fft = r22fft - (T21w.*m11fft + T22w.*m22fft + T23w.*m12fft); 
    r12fft = r12fft - (T31w.*m11fft + T32w.*m22fft + T33w.*m12fft);
    % modify the strain at zero frequency to average strain tensor
    e11fft(1,1) = eps_bar(1)*m*n;  e22fft(1,1) = eps_bar(2)*m*n;  
    e12fft(1,1) = eps_bar(3)*m*n;  
    r11fft(1,1) = eps_bar(4)*m*n;  r22fft(1,1) = eps_bar(5)*m*n;  
    r12fft(1,1) = eps_bar(6)*m*n; 
    % ifft on the strain
    e11 = real(ifftn((e11fft))); e22 = real(ifftn((e22fft))); 
    e12 = real(ifftn((e12fft)));
    r11 = real(ifftn((r11fft))); r22 = real(ifftn((r22fft))); 
    r12 = real(ifftn((r12fft)));
    %% For Parallel updating the constitutive law
    e11 = reshape(e11,[],1); e22 = reshape(e22,[],1); 
    e12 = reshape(e12,[],1); 
    r11 = reshape(r11,[],1); r22 = reshape(r22,[],1); 
    r12 = reshape(r12,[],1); 
    % Calculate the stress
    eT = [e11,e22,e12]; rT = [r11,r22,r12];
    s11 = sum(cons(:,1:3).*eT,2) + sum(cons(:,10:12).*rT,2);
    s22 = sum(cons(:,4:6).*eT,2) + sum(cons(:,13:15).*rT,2);
    s12 = sum(cons(:,7:9).*eT,2) + sum(cons(:,16:18).*rT,2);
    m11 = sum(cons(:,19:21).*rT,2) + sum(cons(:,10:12).*eT,2); 
    m22 = sum(cons(:,22:24).*rT,2) + sum(cons(:,13:15).*eT,2);
    m12 = sum(cons(:,25:27).*rT,2) + sum(cons(:,16:18).*eT,2);
    % Change back to the matrix
    e11 = reshape(e11,[m,n]); s11 = reshape(s11,[m,n]);
    e22 = reshape(e22,[m,n]); s22 = reshape(s22,[m,n]);
    e12 = reshape(e12,[m,n]); s12 = reshape(s12,[m,n]);
    r11 = reshape(r11,[m,n]); m11 = reshape(m11,[m,n]);
    r22 = reshape(r22,[m,n]); m22 = reshape(m22,[m,n]);
    r12 = reshape(r12,[m,n]); m12 = reshape(m12,[m,n]);
    % Display the results
    disp(['Iteration: ',num2str(iter),', Cons: ',num2str(ec)]);
end
%% Homogenisation
stress11ave = mean(reshape(s11,[],1)); stress22ave = mean(reshape(s22,[],1));
stress12ave = mean(reshape(s12,[],1));
moment11ave = mean(reshape(m11,[],1)); moment22ave = mean(reshape(m22,[],1));
moment12ave = mean(reshape(m12,[],1));
%% Visualisation
figure()
subplot(2,3,1)
plotStrain(e11,'E11')
subplot(2,3,2)
plotStrain(e22,'E22')
subplot(2,3,3)
plotStrain(e12,'E12')
subplot(2,3,4)
plotStrain(r11,'T13')
colorbar
subplot(2,3,5)
plotStrain(r22,'T23')
subplot(2,3,6)
plotStrain(r12,'T12')







