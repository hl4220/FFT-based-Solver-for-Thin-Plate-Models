function [T11,T12,T13,T21,T22,T23,T31,T32,T33, ...
          t11,t12,t21,t22,t31,t32, ...
          S11,S12,S21,S22, ...
          s11,s12,s13,s21,s22,s23] = ...
            GreenFunction_Bending_FoPT(mu0,lambda0,G0,e1t,e2t,m,n)
% load functions
load('Green_Functions_FoPT.mat');
T11 = zeros(m,n); T12 = zeros(m,n); T13 = zeros(m,n); 
T21 = zeros(m,n); T22 = zeros(m,n); T23 = zeros(m,n);
T31 = zeros(m,n); T32 = zeros(m,n); T33 = zeros(m,n); 
t11 = zeros(m,n); t12 = zeros(m,n); 
t21 = zeros(m,n); t22 = zeros(m,n); 
t31 = zeros(m,n); t32 = zeros(m,n); 
S11 = zeros(m,n); S12 = zeros(m,n); 
S21 = zeros(m,n); S22 = zeros(m,n);
s11 = zeros(m,n); s12 = zeros(m,n); s13 = zeros(m,n); 
s21 = zeros(m,n); s22 = zeros(m,n); s23 = zeros(m,n);
% Assembly
for i = 1:m
    for j = 1:n

        e1 = e1t(i,j);
        e2 = e2t(i,j);
        E = norm([e1, e2]);
        % Assembly the Green function
        T11(i,j) = Ff_kb11(G0,lambda0,mu0,E,e1);
        T12(i,j) = Ff_kb12(G0,lambda0,mu0,E,e1,e2);
        T13(i,j) = Ff_kb13(G0,lambda0,mu0,E,e1,e2);
        
        T21(i,j) = Ff_kb21(G0,lambda0,mu0,E,e1,e2);
        T22(i,j) = Ff_kb22(G0,lambda0,mu0,E,e2);
        T23(i,j) = Ff_kb23(G0,lambda0,mu0,E,e1,e2);
        
        T31(i,j) = Ff_kb31(G0,lambda0,mu0,E,e1,e2);
        T32(i,j) = Ff_kb32(G0,lambda0,mu0,E,e1,e2);
        T33(i,j) = Ff_kb33(G0,lambda0,mu0,E,e1,e2);

        t11(i,j) = Ff_kg_i11(G0,mu0,E,e1);
        t12(i,j) = Ff_kg_i12(G0,mu0,E,e1,e2);

        t21(i,j) = Ff_kg_i21(G0,mu0,E,e1,e2);
        t22(i,j) = Ff_kg_i22(G0,mu0,E,e2);

        t31(i,j) = Ff_kg_i31(G0,mu0,E,e1,e2);
        t32(i,j) = Ff_kg_i32(G0,mu0,E,e1,e2);
        % S
        S11(i,j) = Ff_sg11(G0,mu0,E,e1);
        S12(i,j) = Ff_sg12(G0,mu0,E,e1,e2);

        S21(i,j) = Ff_sg21(G0,mu0,E,e1,e2);
        S22(i,j) = Ff_sg22(G0,mu0,E,e2);
        % s        
        s11(i,j) = Ff_sb_i11(G0,mu0,E,e1);
        s12(i,j) = Ff_sb_i12(G0,mu0,E,e1,e2);
        s13(i,j) = Ff_sb_i13(G0,mu0,E,e1,e2);
        
        s21(i,j) = Ff_sb_i21(G0,mu0,E,e1,e2);
        s22(i,j) = Ff_sb_i22(G0,mu0,E,e2);
        s23(i,j) = Ff_sb_i23(G0,mu0,E,e1,e2);
        
    end
end 
% Modify the Green tensor at the zero freqency
cpx = 1; cpy = 1; % Does not FFT shift at all!!!1
T11(cpx,cpy) = 0; T12(cpx,cpy) = 0; T13(cpx,cpy) = 0; 
T21(cpx,cpy) = 0; T22(cpx,cpy) = 0; T23(cpx,cpy) = 0;
T31(cpx,cpy) = 0; T32(cpx,cpy) = 0; T33(cpx,cpy) = 0; 
t11(cpx,cpy) = 0; t12(cpx,cpy) = 0; 
t21(cpx,cpy) = 0; t22(cpx,cpy) = 0; 
t31(cpx,cpy) = 0; t32(cpx,cpy) = 0; 
S11(cpx,cpy) = 0; S12(cpx,cpy) = 0; 
S21(cpx,cpy) = 0; S22(cpx,cpy) = 0;
s11(cpx,cpy) = 0; s12(cpx,cpy) = 0; s13(cpx,cpy) = 0; 
s21(cpx,cpy) = 0; s22(cpx,cpy) = 0; s23(cpx,cpy) = 0;
end