function [T11,T12,T13,T21,T22,T23,T31,T32,T33] = ...
            GreenFunction_Membrane(mu0,lamada0,e1t,e2t,m,n)
% Constants in Green's function
c1 = 1/4/mu0; c2 = (lamada0+mu0)/mu0/(lamada0+2*mu0);
T11 = zeros(m,n); T12 = zeros(m,n); T13 = zeros(m,n);
T22 = zeros(m,n); T23 = zeros(m,n); T33 = zeros(m,n);
for i = 1:m
    for j = 1:n
        % Willot's Scheme based on rotated Grid
        e1 = e1t(i,j);
        e2 = e2t(i,j);
        E = norm([e1, e2]);
        % Assembly the Green function
        T11(i,j) = c1/E^2*(4*e1^2)-c2*e1^4/E^4;
        T12(i,j) = -c2*e1^2*e2^2/E^4;
        T13(i,j) = c1/E^2*(2*e1*e2)-c2*e1^3*e2/E^4;
        
        T22(i,j) = c1/E^2*(4*e2^2)-c2*e2^4/E^4;
        T23(i,j) = c1/E^2*(2*e1*e2)-c2*e2^3*e1/E^4;
        
        T33(i,j) = c1/E^2*(e1^2+e2^2)-c2*e1^2*e2^2/E^4;
        
    end
end
% modify the Green function tensor according to voigt notation
T13 = T13*2; T23 = T23*2;
T33 = T33*4; 
% Complete the symmetric part
T21 = T12; T31 = T13; T32 = T23; 
% Modify the Green tensor at the zero freqency
cpx = 1; cpy = 1; % Does not FFT shift at all!!!1
T11(cpx,cpy) = 0; T12(cpx,cpy) = 0; T13(cpx,cpy) = 0; 
T21(cpx,cpy) = 0; T22(cpx,cpy) = 0; T23(cpx,cpy) = 0;
T31(cpx,cpy) = 0; T32(cpx,cpy) = 0; T33(cpx,cpy) = 0; 
end